<?php

namespace Hiberus\Curso\model;

class Author
{
    public function getAuthorName(){
        return 'J.K.ROWLING';
    }
}
